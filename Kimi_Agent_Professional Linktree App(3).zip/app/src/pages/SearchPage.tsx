import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Link2, 
  Loader2, 
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Sparkles,
  User as UserIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { publicApi } from '@/services/api';
import type { User } from '@/types';
import { toast } from 'sonner';

interface UserWithLinkCount extends User {
  linkCount: number;
}

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [users, setUsers] = useState<UserWithLinkCount[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [hasSearched, setHasSearched] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const searchUsers = useCallback(async (searchQuery: string, pageNum: number = 1) => {
    setIsLoading(true);
    try {
      const result = await publicApi.searchUsers(searchQuery, pageNum, 12);
      // Cast users to include linkCount
      const usersWithCount = result.users.map(u => ({ ...u, linkCount: (u as any).linkCount || 0 }));
      setUsers(usersWithCount as UserWithLinkCount[]);
      setTotalPages(result.totalPages);
      setTotal(result.total);
      setPage(result.page);
      setHasSearched(true);
    } catch (error: any) {
      toast.error(error.message || 'Failed to search users');
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial load - show all users
  useEffect(() => {
    searchUsers('', 1);
  }, [searchUsers]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      searchUsers(query, 1);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, searchUsers]);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      searchUsers(query, newPage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const clearSearch = () => {
    setQuery('');
    inputRef.current?.focus();
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl" />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-slate-800/50 backdrop-blur-xl bg-slate-950/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                <Link2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Hareg Link</span>
            </Link>
            <div className="flex items-center gap-3">
              <Link to="/login">
                <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white hover:bg-slate-800">
                  Log in
                </Button>
              </Link>
              <Link to="/register">
                <Button size="sm" className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0">
                  Sign up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero / Search */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-300 text-sm mb-6">
            <Sparkles className="w-4 h-4" />
            <span>Ethiopia's Link-in-Bio Platform 🇪🇹</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Discover <span className="bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">Creators</span>
          </h1>
          <p className="text-slate-400 text-lg max-w-xl mx-auto mb-8">
            Find and connect with Ethiopian creators, artists, and influencers
          </p>

          {/* Search Box */}
          <div className="relative max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <Input
                ref={inputRef}
                type="text"
                placeholder="Search by name, username, or bio..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-12 pr-10 py-6 text-lg bg-slate-900/80 border-slate-700 text-white placeholder:text-slate-500 focus:border-violet-500 focus:ring-violet-500/20 rounded-xl"
              />
              {query && (
                <button
                  onClick={clearSearch}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  ×
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Results */}
        <div>
          {/* Stats */}
          {hasSearched && !isLoading && (
            <div className="flex items-center justify-between mb-6">
              <p className="text-slate-400">
                {query ? (
                  <>Found <span className="text-white font-medium">{total}</span> results for "{query}"</>
                ) : (
                  <>Showing <span className="text-white font-medium">{total}</span> creators</>
                )}
              </p>
            </div>
          )}

          {/* Loading */}
          {isLoading && users.length === 0 && (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
            </div>
          )}

          {/* Users Grid */}
          {!isLoading && users.length > 0 && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {users.map((user) => (
                  <Link
                    key={user.id}
                    to={`/u/${user.username}`}
                    className="group p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-violet-500/50 transition-all duration-300 hover:scale-[1.02]"
                  >
                    <div className="flex items-start gap-4">
                      {/* Avatar */}
                      <div className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                        <span className="text-xl font-bold text-white">
                          {user.displayName[0]?.toUpperCase()}
                        </span>
                      </div>
                      
                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-white truncate group-hover:text-violet-300 transition-colors">
                            {user.displayName}
                          </h3>
                          {user.isVerified && (
                            <CheckCircle2 className="w-4 h-4 text-blue-400 fill-blue-400 flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-sm text-slate-400 truncate">@{user.username}</p>
                        {user.bio && (
                          <p className="text-sm text-slate-500 mt-1 line-clamp-2">{user.bio}</p>
                        )}
                        <div className="flex items-center gap-3 mt-3">
                          <span className="text-xs text-slate-500 flex items-center gap-1">
                            <Link2 className="w-3 h-3" />
                            {user.linkCount} links
                          </span>
                        </div>
                      </div>
                      
                      {/* Arrow */}
                      <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-violet-400 transition-colors flex-shrink-0 opacity-0 group-hover:opacity-100" />
                    </div>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-8">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(page - 1)}
                    disabled={page === 1 || isLoading}
                    className="border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  
                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }, (_, i) => i + 1)
                      .filter(p => p === 1 || p === totalPages || (p >= page - 1 && p <= page + 1))
                      .map((p, i, arr) => (
                        <span key={p} className="flex items-center">
                          {i > 0 && arr[i - 1] !== p - 1 && (
                            <span className="px-2 text-slate-500">...</span>
                          )}
                          <Button
                            variant={page === p ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => handlePageChange(p)}
                            disabled={isLoading}
                            className={
                              page === p
                                ? 'bg-violet-500 hover:bg-violet-600 text-white'
                                : 'border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white'
                            }
                          >
                            {p}
                          </Button>
                        </span>
                      ))}
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handlePageChange(page + 1)}
                    disabled={page === totalPages || isLoading}
                    className="border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </>
          )}

          {/* Empty State */}
          {!isLoading && users.length === 0 && hasSearched && (
            <div className="text-center py-16">
              <div className="w-20 h-20 rounded-full bg-slate-800/50 flex items-center justify-center mx-auto mb-4">
                <UserIcon className="w-10 h-10 text-slate-500" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                {query ? 'No users found' : 'No users yet'}
              </h3>
              <p className="text-slate-400 mb-6">
                {query 
                  ? `No results for "${query}". Try a different search.` 
                  : 'Be the first to create a profile!'}
              </p>
              <Link to="/register">
                <Button className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0">
                  Create Your Profile
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800/50 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                <Link2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Hareg Link</span>
            </div>
            <p className="text-slate-500 text-sm">
              Ethiopia's Link-in-Bio Platform 🇪🇹
            </p>
            <p className="text-slate-600 text-sm">
              © 2026 Hareg Link. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
