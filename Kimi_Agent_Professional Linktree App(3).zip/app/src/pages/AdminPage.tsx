import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Link2, 
  ArrowLeft, 
  Users, 
  BarChart3, 
  Loader2,
  Search,
  UserX,
  UserCheck,
  Shield,
  Trash2,
  ExternalLink,
  Eye,
  Link as LinkIcon,
  Pencil,
  CheckCircle2,
  X,
  Save
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { adminApi } from '@/services/api';
import type { User, Link as LinkType, AdminStats, ThemeType } from '@/types';
import { THEMES } from '@/types';
import { toast } from 'sonner';

export default function AdminPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [links, setLinks] = useState<(LinkType & { username: string })[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [statsData, usersData, linksData] = await Promise.all([
        adminApi.getStats(),
        adminApi.getAllUsers(),
        adminApi.getAllLinks()
      ]);
      setStats(statsData);
      setUsers(usersData);
      setLinks(linksData);
    } catch (error: any) {
      toast.error(error.message || 'Failed to load admin data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      await adminApi.updateUser(userId, { isActive: !currentStatus });
      toast.success(`User ${currentStatus ? 'deactivated' : 'activated'} successfully`);
      loadData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    }
  };

  const handleToggleAdmin = async (userId: string, currentStatus: boolean) => {
    try {
      await adminApi.updateUser(userId, { isAdmin: !currentStatus });
      toast.success(`Admin status ${currentStatus ? 'removed' : 'granted'} successfully`);
      loadData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    }
  };

  const handleToggleVerified = async (userId: string, currentStatus: boolean) => {
    try {
      await adminApi.updateUser(userId, { isVerified: !currentStatus });
      toast.success(`User ${currentStatus ? 'unverified' : 'verified'} successfully`);
      loadData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) return;
    
    try {
      await adminApi.deleteUser(userId);
      toast.success('User deleted successfully');
      loadData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete user');
    }
  };

  const handleEditUser = (user: User) => {
    setEditingUser({ ...user });
    setShowEditDialog(true);
  };

  const handleSaveUser = async () => {
    if (!editingUser) return;
    
    setIsSubmitting(true);
    try {
      await adminApi.editUserFullProfile(editingUser.id, {
        displayName: editingUser.displayName,
        bio: editingUser.bio,
        username: editingUser.username,
        email: editingUser.email,
        theme: editingUser.theme,
        isVerified: editingUser.isVerified,
        isActive: editingUser.isActive,
        isAdmin: editingUser.isAdmin,
      });
      toast.success('User updated successfully');
      setShowEditDialog(false);
      setEditingUser(null);
      loadData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredLinks = links.filter(l => 
    l.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    l.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800/50 backdrop-blur-xl bg-slate-950/80 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-violet-400" />
                <h1 className="text-xl font-semibold text-white">Admin Panel</h1>
              </div>
            </div>
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                <Link2 className="w-5 h-5 text-white" />
              </div>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-900 border border-slate-800 mb-8">
            <TabsTrigger value="overview" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-300">
              <BarChart3 className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-300">
              <Users className="w-4 h-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger value="links" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-300">
              <LinkIcon className="w-4 h-4 mr-2" />
              Links
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
                    <Users className="w-6 h-6 text-violet-400" />
                  </div>
                  <span className="text-3xl font-bold text-white">{stats?.totalUsers}</span>
                </div>
                <h3 className="text-slate-400">Total Users</h3>
                <p className="text-sm text-slate-500 mt-1">
                  {stats?.activeUsers} active
                </p>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                    <LinkIcon className="w-6 h-6 text-blue-400" />
                  </div>
                  <span className="text-3xl font-bold text-white">{stats?.totalLinks}</span>
                </div>
                <h3 className="text-slate-400">Total Links</h3>
                <p className="text-sm text-slate-500 mt-1">
                  {stats?.activeLinks} active
                </p>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-emerald-400" />
                  </div>
                  <span className="text-3xl font-bold text-white">{stats?.totalClicks}</span>
                </div>
                <h3 className="text-slate-400">Total Clicks</h3>
                <p className="text-sm text-slate-500 mt-1">
                  Across all links
                </p>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-amber-400" />
                  </div>
                  <span className="text-3xl font-bold text-white">{stats?.verifiedUsers}</span>
                </div>
                <h3 className="text-slate-400">Verified Users</h3>
                <p className="text-sm text-slate-500 mt-1">
                  Verified accounts
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-slate-800">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <Input
                    placeholder="Search users..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-800/50">
                    <tr>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">User</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Role</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Status</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Joined</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-slate-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-800/30">
                        <td className="px-4 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white font-medium">
                              {u.displayName[0]?.toUpperCase()}
                            </div>
                            <div>
                              <div className="flex items-center gap-1">
                                <p className="text-white font-medium">{u.displayName}</p>
                                {u.isVerified && (
                                  <CheckCircle2 className="w-4 h-4 text-blue-400 fill-blue-400" />
                                )}
                              </div>
                              <p className="text-sm text-slate-400">@{u.username}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          {u.isAdmin ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-violet-500/10 text-violet-400 text-xs">
                              <Shield className="w-3 h-3" />
                              Admin
                            </span>
                          ) : (
                            <span className="text-slate-400 text-sm">User</span>
                          )}
                        </td>
                        <td className="px-4 py-4">
                          {u.isActive ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs">
                              <UserCheck className="w-3 h-3" />
                              Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/10 text-red-400 text-xs">
                              <UserX className="w-3 h-3" />
                              Inactive
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4 text-slate-400 text-sm">
                          {new Date(u.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center justify-end gap-1">
                            <Link to={`/u/${u.username}`} target="_blank">
                              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                                <ExternalLink className="w-4 h-4" />
                              </Button>
                            </Link>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditUser(u)}
                              className="text-slate-400 hover:text-white"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleToggleVerified(u.id, u.isVerified)}
                              className={u.isVerified ? 'text-blue-400 hover:text-blue-300' : 'text-slate-400 hover:text-blue-400'}
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleToggleAdmin(u.id, u.isAdmin)}
                              disabled={u.id === user?.id}
                              className={`${u.isAdmin ? 'text-violet-400' : 'text-slate-400'} hover:text-white`}
                            >
                              <Shield className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleToggleUserStatus(u.id, u.isActive)}
                              disabled={u.id === user?.id}
                              className={u.isActive ? 'text-emerald-400 hover:text-white' : 'text-red-400 hover:text-white'}
                            >
                              {u.isActive ? <UserCheck className="w-4 h-4" /> : <UserX className="w-4 h-4" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteUser(u.id)}
                              disabled={u.id === user?.id}
                              className="text-slate-400 hover:text-red-400"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          {/* Links Tab */}
          <TabsContent value="links">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-slate-800">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                  <Input
                    placeholder="Search links..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-800/50">
                    <tr>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Link</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Owner</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Status</th>
                      <th className="text-left px-4 py-3 text-sm font-medium text-slate-400">Clicks</th>
                      <th className="text-right px-4 py-3 text-sm font-medium text-slate-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredLinks.map((link) => (
                      <tr key={link.id} className="hover:bg-slate-800/30">
                        <td className="px-4 py-4">
                          <div>
                            <p className="text-white font-medium">{link.title}</p>
                            <p className="text-sm text-slate-400 truncate max-w-xs">{link.url}</p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className="text-slate-300 text-sm">@{link.username}</span>
                        </td>
                        <td className="px-4 py-4">
                          {link.isActive ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs">
                              <Eye className="w-3 h-3" />
                              Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/10 text-red-400 text-xs">
                              <UserX className="w-3 h-3" />
                              Inactive
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4 text-slate-300">
                          {link.clicks || 0}
                        </td>
                        <td className="px-4 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <Link to={link.url} target="_blank">
                              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
                                <ExternalLink className="w-4 h-4" />
                              </Button>
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>
          
          {editingUser && (
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Username</Label>
                  <Input
                    value={editingUser.username}
                    onChange={(e) => setEditingUser({ ...editingUser, username: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={editingUser.email}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Display Name</Label>
                <Input
                  value={editingUser.displayName}
                  onChange={(e) => setEditingUser({ ...editingUser, displayName: e.target.value })}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Bio</Label>
                <Textarea
                  value={editingUser.bio}
                  onChange={(e) => setEditingUser({ ...editingUser, bio: e.target.value })}
                  rows={3}
                  className="bg-slate-800 border-slate-700 text-white resize-none"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Theme</Label>
                <Select 
                  value={editingUser.theme} 
                  onValueChange={(value) => setEditingUser({ ...editingUser, theme: value as ThemeType })}
                >
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {Object.entries(THEMES).map(([key, theme]) => (
                      <SelectItem key={key} value={key} className="text-white">
                        {theme.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-3 gap-4 pt-4">
                <button
                  type="button"
                  onClick={() => setEditingUser({ ...editingUser, isVerified: !editingUser.isVerified })}
                  className={`p-3 rounded-xl border-2 transition-all ${
                    editingUser.isVerified 
                      ? 'border-blue-500 bg-blue-500/10' 
                      : 'border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <CheckCircle2 className={`w-5 h-5 mx-auto mb-1 ${editingUser.isVerified ? 'text-blue-400' : 'text-slate-500'}`} />
                  <p className="text-xs text-slate-300">Verified</p>
                </button>
                
                <button
                  type="button"
                  onClick={() => setEditingUser({ ...editingUser, isAdmin: !editingUser.isAdmin })}
                  className={`p-3 rounded-xl border-2 transition-all ${
                    editingUser.isAdmin 
                      ? 'border-violet-500 bg-violet-500/10' 
                      : 'border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <Shield className={`w-5 h-5 mx-auto mb-1 ${editingUser.isAdmin ? 'text-violet-400' : 'text-slate-500'}`} />
                  <p className="text-xs text-slate-300">Admin</p>
                </button>
                
                <button
                  type="button"
                  onClick={() => setEditingUser({ ...editingUser, isActive: !editingUser.isActive })}
                  className={`p-3 rounded-xl border-2 transition-all ${
                    editingUser.isActive 
                      ? 'border-emerald-500 bg-emerald-500/10' 
                      : 'border-red-500 bg-red-500/10'
                  }`}
                >
                  {editingUser.isActive ? (
                    <UserCheck className="w-5 h-5 mx-auto mb-1 text-emerald-400" />
                  ) : (
                    <UserX className="w-5 h-5 mx-auto mb-1 text-red-400" />
                  )}
                  <p className="text-xs text-slate-300">{editingUser.isActive ? 'Active' : 'Inactive'}</p>
                </button>
              </div>
            </div>
          )}
          
          <DialogFooter className="mt-6">
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleSaveUser}
              disabled={isSubmitting}
              className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white"
            >
              {isSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
