import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Link2, 
  ExternalLink, 
  Loader2, 
  AlertCircle,
  CheckCircle2,
  ArrowLeft,
  Share2,
  QrCode,
  X,
  Twitter,
  Instagram,
  Linkedin,
  Youtube,
  Facebook,
  Github,
  Globe,
  Music,
  Video,
  MessageCircle,
  Send,
  Ghost,
  Pin,
  Cloud,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { publicApi, linksApi } from '@/services/api';
import type { Link as LinkType, ThemeType, SocialLink, SocialPlatform } from '@/types';
import { THEMES, LINK_COLORS, SOCIAL_PLATFORMS } from '@/types';
import QRCode from 'qrcode';
import { toast } from 'sonner';

const socialIconMap: Record<SocialPlatform, React.ElementType> = {
  twitter: Twitter,
  instagram: Instagram,
  facebook: Facebook,
  linkedin: Linkedin,
  youtube: Youtube,
  tiktok: Music,
  github: Github,
  telegram: Send,
  whatsapp: MessageCircle,
  snapchat: Ghost,
  pinterest: Pin,
  spotify: Music,
  soundcloud: Cloud,
  twitch: Video,
  discord: MessageSquare,
  website: Globe,
};

interface ProfileData {
  username: string;
  displayName: string;
  bio: string;
  avatar: string | null;
  theme: ThemeType;
  isVerified: boolean;
  socialLinks: SocialLink[];
  links: LinkType[];
}

export default function PublicProfilePage() {
  const { username } = useParams<{ username: string }>();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState('');

  useEffect(() => {
    if (username) {
      loadProfile();
    }
  }, [username]);

  const loadProfile = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await publicApi.getUserProfile(username!);
      if (data) {
        setProfile(data);
        // Generate QR code
        const profileUrl = `${window.location.origin}/u/${username}`;
        const qrUrl = await QRCode.toDataURL(profileUrl, {
          width: 300,
          margin: 2,
          color: {
            dark: '#8B5CF6',
            light: '#00000000',
          },
        });
        setQrCodeUrl(qrUrl);
      } else {
        setError('Profile not found');
      }
    } catch (err) {
      setError('Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLinkClick = async (link: LinkType) => {
    await linksApi.trackClick(link.id);
    window.open(link.url, '_blank', 'noopener,noreferrer');
  };

  const handleShare = async () => {
    const profileUrl = `${window.location.origin}/u/${username}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${profile?.displayName} on Hareg Link`,
          text: profile?.bio || '',
          url: profileUrl,
        });
      } catch {
        // User cancelled
      }
    } else {
      navigator.clipboard.writeText(profileUrl);
      toast.success('Profile URL copied!');
    }
  };

  const downloadQR = () => {
    const link = document.createElement('a');
    link.href = qrCodeUrl;
    link.download = `${username}-hareg-link-qr.png`;
    link.click();
    toast.success('QR code downloaded!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">Profile Not Found</h1>
          <p className="text-slate-400 mb-6">The profile you're looking for doesn't exist or has been removed.</p>
          <Link to="/">
            <Button className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const theme = THEMES[profile.theme] || THEMES.dark;

  return (
    <div className={`min-h-screen w-full bg-gradient-to-br ${theme.gradient} flex flex-col`}>
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className={`absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-20 ${theme.accent === 'violet' ? 'bg-violet-600' : theme.accent === 'indigo' ? 'bg-indigo-600' : theme.accent === 'orange' ? 'bg-orange-600' : theme.accent === 'emerald' ? 'bg-emerald-600' : theme.accent === 'cyan' ? 'bg-cyan-600' : theme.accent === 'yellow' ? 'bg-yellow-600' : 'bg-gray-600'}`} />
        <div className={`absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full blur-3xl opacity-20 ${theme.accent === 'violet' ? 'bg-purple-600' : theme.accent === 'indigo' ? 'bg-purple-600' : theme.accent === 'orange' ? 'bg-red-600' : theme.accent === 'emerald' ? 'bg-teal-600' : theme.accent === 'cyan' ? 'bg-blue-600' : theme.accent === 'yellow' ? 'bg-red-600' : 'bg-gray-500'}`} />
      </div>

      {/* Header */}
      <header className="relative z-10 p-4">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <Link to="/">
            <Button variant="ghost" size="icon" className={`${theme.subtext} hover:${theme.text}`}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setShowQRDialog(true)}
              className={`${theme.subtext} hover:${theme.text}`}
            >
              <QrCode className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleShare}
              className={`${theme.subtext} hover:${theme.text}`}
            >
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-4 py-8 relative z-10">
        <div className="w-full max-w-md">
          {/* Profile Section */}
          <div className="text-center mb-8">
            {/* Avatar */}
            <div className="relative inline-block mb-4">
              <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500">
                <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center overflow-hidden">
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                    <span className="text-4xl font-bold text-white">
                      {profile.displayName[0]?.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
              {profile.isVerified && (
                <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center border-4 border-slate-900">
                  <CheckCircle2 className="w-5 h-5 text-white" />
                </div>
              )}
            </div>

            {/* Name & Bio */}
            <div className="flex items-center justify-center gap-2 mb-1">
              <h1 className={`text-2xl sm:text-3xl font-bold ${theme.text}`}>
                {profile.displayName}
              </h1>
              {profile.isVerified && (
                <CheckCircle2 className="w-6 h-6 text-blue-500 fill-blue-500" />
              )}
            </div>
            <p className={theme.subtext}>@{profile.username}</p>
            {profile.bio && (
              <p className={`mt-4 ${theme.subtext} max-w-xs mx-auto leading-relaxed`}>
                {profile.bio}
              </p>
            )}

            {/* Social Links */}
            {profile.socialLinks.length > 0 && (
              <div className="flex items-center justify-center gap-3 mt-6">
                {profile.socialLinks
                  .sort((a, b) => a.order - b.order)
                  .map((social) => {
                    const platform = SOCIAL_PLATFORMS.find(p => p.value === social.platform);
                    const Icon = platform ? socialIconMap[social.platform] : Globe;
                    
                    return (
                      <a
                        key={social.id}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group relative w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
                        style={{ backgroundColor: platform?.color + '20' }}
                        title={platform?.label}
                      >
                        <Icon 
                          className="w-5 h-5 transition-colors" 
                          style={{ color: platform?.color }}
                        />
                        <span 
                          className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          style={{ backgroundColor: platform?.color + '30' }}
                        />
                      </a>
                    );
                  })}
              </div>
            )}
          </div>

          {/* Links Section */}
          <div className="space-y-3">
            {profile.links.length === 0 ? (
              <div className={`text-center py-8 ${theme.card} rounded-2xl border`}>
                <p className={theme.subtext}>No links yet</p>
              </div>
            ) : (
              profile.links.map((link) => {
                const colorOption = LINK_COLORS.find(c => c.value === link.color);
                const gradientClass = colorOption?.gradient || 'from-blue-500 to-blue-600';
                
                return (
                  <button
                    key={link.id}
                    onClick={() => handleLinkClick(link)}
                    className="group w-full relative overflow-hidden rounded-2xl transition-all duration-300 hover:scale-[1.02]"
                  >
                    {/* Card background */}
                    <div className={`absolute inset-0 bg-gradient-to-r ${gradientClass} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
                    
                    {/* Default background */}
                    <div className={`absolute inset-0 ${theme.card} border group-hover:border-transparent transition-all duration-300 rounded-2xl`} />
                    
                    {/* Content */}
                    <div className="relative flex items-center gap-4 p-4">
                      {/* Icon */}
                      <div className={`flex-shrink-0 w-12 h-12 rounded-xl bg-slate-900/20 group-hover:bg-white/20 flex items-center justify-center ${theme.subtext} group-hover:text-white transition-all duration-300`}>
                        <span className="text-lg">
                          {link.icon === 'globe' && '🌐'}
                          {link.icon === 'github' && '💻'}
                          {link.icon === 'twitter' && '🐦'}
                          {link.icon === 'instagram' && '📸'}
                          {link.icon === 'linkedin' && '💼'}
                          {link.icon === 'youtube' && '📺'}
                          {link.icon === 'facebook' && '👥'}
                          {link.icon === 'mail' && '✉️'}
                          {link.icon === 'music' && '🎵'}
                          {link.icon === 'video' && '🎬'}
                          {link.icon === 'shopping' && '🛍️'}
                          {link.icon === 'coffee' && '☕'}
                          {link.icon === 'book' && '📖'}
                          {link.icon === 'code' && '💻'}
                          {link.icon === 'link' && '🔗'}
                        </span>
                      </div>

                      {/* Text */}
                      <div className="flex-1 text-left">
                        <h3 className={`font-semibold ${theme.text} group-hover:text-white transition-colors duration-300`}>
                          {link.title}
                        </h3>
                      </div>

                      {/* Arrow */}
                      <div className={`flex-shrink-0 ${theme.subtext} group-hover:text-white/80 transition-all duration-300 transform group-hover:translate-x-1`}>
                        <ExternalLink className="w-5 h-5" />
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Footer */}
          <div className="mt-12 text-center">
            <Link to="/" className={`inline-flex items-center gap-2 text-sm ${theme.subtext} hover:text-violet-400 transition-colors`}>
              <div className="w-6 h-6 rounded bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                <Link2 className="w-3 h-3 text-white" />
              </div>
              Create your own Hareg Link
            </Link>
          </div>
        </div>
      </main>

      {/* QR Code Dialog */}
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-center">Share Profile</DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center py-4">
            <div className="bg-white p-4 rounded-xl mb-4">
              {qrCodeUrl && (
                <img src={qrCodeUrl} alt="QR Code" className="w-48 h-48" />
              )}
            </div>
            
            <p className="text-slate-400 text-center mb-4">
              Scan this QR code to visit {profile.displayName}'s profile
            </p>
            
            <div className="flex gap-2 w-full">
              <Button
                variant="outline"
                className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800"
                onClick={() => setShowQRDialog(false)}
              >
                <X className="w-4 h-4 mr-2" />
                Close
              </Button>
              <Button
                className="flex-1 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white"
                onClick={downloadQR}
              >
                <QrCode className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
