import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Link2, 
  Plus, 
  ExternalLink, 
  Settings, 
  LogOut, 
  BarChart3,
  Shield,
  GripVertical,
  Pencil,
  Trash2,
  Eye,
  EyeOff,
  Loader2,
  Copy,
  Check,
  QrCode,
  Share2,
  Twitter,
  Instagram,
  Linkedin,
  Youtube,
  Facebook,
  Github,
  Globe,
  Music,
  Video,
  MessageCircle,
  Send,
  Ghost,
  Pin,
  Cloud,
  MessageSquare,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { linksApi, authApi } from '@/services/api';
import type { Link as LinkType, SocialLink, SocialPlatform } from '@/types';
import { LINK_COLORS, LINK_ICONS, SOCIAL_PLATFORMS } from '@/types';
import { toast } from 'sonner';
import QRCode from 'qrcode';

const socialIconMap: Record<SocialPlatform, React.ElementType> = {
  twitter: Twitter,
  instagram: Instagram,
  facebook: Facebook,
  linkedin: Linkedin,
  youtube: Youtube,
  tiktok: Music,
  github: Github,
  telegram: Send,
  whatsapp: MessageCircle,
  snapchat: Ghost,
  pinterest: Pin,
  spotify: Music,
  soundcloud: Cloud,
  twitch: Video,
  discord: MessageSquare,
  website: Globe,
};

export default function DashboardPage() {
  const navigate = useNavigate();
  const { user, logout, isAdmin, updateUser } = useAuth();
  const [links, setLinks] = useState<LinkType[]>([]);
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>(user?.socialLinks || []);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showSocialDialog, setShowSocialDialog] = useState(false);
  const [showQRDialog, setShowQRDialog] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [editingLink, setEditingLink] = useState<LinkType | null>(null);
  const [editingSocial, setEditingSocial] = useState<SocialLink | null>(null);
  const [copied, setCopied] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    url: '',
    icon: 'link',
    color: 'blue'
  });
  
  const [socialFormData, setSocialFormData] = useState({
    platform: 'twitter' as SocialPlatform,
    url: ''
  });

  useEffect(() => {
    loadLinks();
    generateQR();
  }, []);

  useEffect(() => {
    if (user?.socialLinks) {
      setSocialLinks(user.socialLinks);
    }
  }, [user]);

  const generateQR = async () => {
    if (user?.username) {
      const profileUrl = `${window.location.origin}/u/${user.username}`;
      const qrUrl = await QRCode.toDataURL(profileUrl, {
        width: 300,
        margin: 2,
        color: {
          dark: '#8B5CF6',
          light: '#00000000',
        },
      });
      setQrCodeUrl(qrUrl);
    }
  };

  const loadLinks = async () => {
    try {
      const data = await linksApi.getMyLinks();
      setLinks(data);
    } catch (error: any) {
      toast.error(error.message || 'Failed to load links');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
    toast.success('Logged out successfully');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.url) {
      toast.error('Title and URL are required');
      return;
    }

    setIsSubmitting(true);
    
    try {
      if (editingLink) {
        await linksApi.updateLink(editingLink.id, formData);
        toast.success('Link updated successfully');
      } else {
        await linksApi.createLink(formData);
        toast.success('Link created successfully');
      }
      
      setShowAddDialog(false);
      setEditingLink(null);
      setFormData({ title: '', url: '', icon: 'link', color: 'blue' });
      loadLinks();
    } catch (error: any) {
      toast.error(error.message || 'Failed to save link');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSocialSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!socialFormData.url) {
      toast.error('URL is required');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const currentSocials = user?.socialLinks || [];
      let updatedSocials: SocialLink[];
      
      if (editingSocial) {
        updatedSocials = currentSocials.map(s => 
          s.id === editingSocial.id 
            ? { ...s, ...socialFormData }
            : s
        );
      } else {
        const newSocial: SocialLink = {
          id: Math.random().toString(36).substring(2) + Date.now().toString(36),
          ...socialFormData,
          order: currentSocials.length
        };
        updatedSocials = [...currentSocials, newSocial];
      }
      
      const updatedUser = await authApi.updateProfile({ socialLinks: updatedSocials });
      updateUser(updatedUser);
      setSocialLinks(updatedSocials);
      
      toast.success(editingSocial ? 'Social link updated' : 'Social link added');
      setShowSocialDialog(false);
      setEditingSocial(null);
      setSocialFormData({ platform: 'twitter', url: '' });
    } catch (error: any) {
      toast.error(error.message || 'Failed to save social link');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteSocial = async (id: string) => {
    if (!confirm('Are you sure you want to remove this social link?')) return;
    
    try {
      const updatedSocials = (user?.socialLinks || []).filter(s => s.id !== id);
      const updatedUser = await authApi.updateProfile({ socialLinks: updatedSocials });
      updateUser(updatedUser);
      setSocialLinks(updatedSocials);
      toast.success('Social link removed');
    } catch (error: any) {
      toast.error(error.message || 'Failed to remove social link');
    }
  };

  const handleEdit = (link: LinkType) => {
    setEditingLink(link);
    setFormData({
      title: link.title,
      url: link.url,
      icon: link.icon,
      color: link.color
    });
    setShowAddDialog(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this link?')) return;
    
    try {
      await linksApi.deleteLink(id);
      toast.success('Link deleted successfully');
      loadLinks();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete link');
    }
  };

  const toggleLinkStatus = async (link: LinkType) => {
    try {
      await linksApi.updateLink(link.id, { isActive: !link.isActive });
      toast.success(link.isActive ? 'Link hidden' : 'Link activated');
      loadLinks();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update link');
    }
  };

  const copyProfileUrl = () => {
    const url = `${window.location.origin}/u/${user?.username}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    toast.success('Profile URL copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadQR = () => {
    const link = document.createElement('a');
    link.href = qrCodeUrl;
    link.download = `${user?.username}-hareg-link-qr.png`;
    link.click();
    toast.success('QR code downloaded!');
  };

  const totalClicks = links.reduce((sum, link) => sum + (link.clicks || 0), 0);
  const activeLinks = links.filter(l => l.isActive).length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800/50 backdrop-blur-xl bg-slate-950/80 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
                  <Link2 className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-white">Hareg Link</span>
              </Link>
            </div>
            
            <div className="flex items-center gap-2">
              {isAdmin && (
                <Link to="/admin">
                  <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white hover:bg-slate-800">
                    <Shield className="w-4 h-4 mr-2" />
                    Admin
                  </Button>
                </Link>
              )}
              <Link to="/profile">
                <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white hover:bg-slate-800">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-slate-300 hover:text-red-400 hover:bg-red-500/10">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              {/* Profile Card */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white text-2xl font-bold">
                    {user?.displayName?.[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg font-semibold text-white truncate">{user?.displayName}</h2>
                      {user?.isVerified && (
                        <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-xs font-medium">
                          Verified
                        </span>
                      )}
                    </div>
                    <p className="text-slate-400">@{user?.username}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full border-slate-700 text-slate-300 hover:bg-slate-800"
                    onClick={copyProfileUrl}
                  >
                    {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                    {copied ? 'Copied!' : 'Copy Profile URL'}
                  </Button>
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      variant="outline" 
                      className="border-slate-700 text-slate-300 hover:bg-slate-800"
                      onClick={() => setShowQRDialog(true)}
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Code
                    </Button>
                    <Link to={`/u/${user?.username}`} target="_blank">
                      <Button variant="outline" className="w-full border-slate-700 text-slate-300 hover:bg-slate-800">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
                <h3 className="text-sm font-medium text-slate-400 mb-4">Statistics</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <Link2 className="w-4 h-4" />
                      <span className="text-xs">Links</span>
                    </div>
                    <p className="text-2xl font-bold text-white">{links.length}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <Eye className="w-4 h-4" />
                      <span className="text-xs">Active</span>
                    </div>
                    <p className="text-2xl font-bold text-white">{activeLinks}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-800/50 col-span-2">
                    <div className="flex items-center gap-2 text-slate-400 mb-1">
                      <BarChart3 className="w-4 h-4" />
                      <span className="text-xs">Total Clicks</span>
                    </div>
                    <p className="text-2xl font-bold text-white">{totalClicks}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="links" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-900 border border-slate-800 mb-6">
                <TabsTrigger value="links" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-300">
                  <Link2 className="w-4 h-4 mr-2" />
                  Links
                </TabsTrigger>
                <TabsTrigger value="social" className="data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-300">
                  <Share2 className="w-4 h-4 mr-2" />
                  Social
                </TabsTrigger>
              </TabsList>

              {/* Links Tab */}
              <TabsContent value="links">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h1 className="text-2xl font-bold text-white">Your Links</h1>
                    <p className="text-slate-400">Manage and organize your links</p>
                  </div>
                  <Button 
                    onClick={() => {
                      setEditingLink(null);
                      setFormData({ title: '', url: '', icon: 'link', color: 'blue' });
                      setShowAddDialog(true);
                    }}
                    className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Link
                  </Button>
                </div>

                {/* Links List */}
                <div className="space-y-3">
                  {links.length === 0 ? (
                    <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
                      <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4">
                        <Link2 className="w-8 h-8 text-slate-500" />
                      </div>
                      <h3 className="text-lg font-medium text-white mb-2">No links yet</h3>
                      <p className="text-slate-400 mb-4">Add your first link to get started</p>
                      <Button 
                        onClick={() => setShowAddDialog(true)}
                        className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Your First Link
                      </Button>
                    </div>
                  ) : (
                    links.map((link) => (
                      <div 
                        key={link.id}
                        className={`group flex items-center gap-4 p-4 rounded-xl bg-slate-900/80 border ${
                          link.isActive ? 'border-slate-800' : 'border-slate-800/50 opacity-60'
                        } hover:border-violet-500/50 transition-all`}
                      >
                        <div className="flex-shrink-0 cursor-grab">
                          <GripVertical className="w-5 h-5 text-slate-600" />
                        </div>
                        
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${
                          LINK_COLORS.find(c => c.value === link.color)?.gradient || 'from-blue-500 to-blue-600'
                        } flex items-center justify-center text-white`}>
                          <span className="text-lg">
                            {link.icon === 'globe' && '🌐'}
                            {link.icon === 'github' && '💻'}
                            {link.icon === 'twitter' && '🐦'}
                            {link.icon === 'instagram' && '📸'}
                            {link.icon === 'linkedin' && '💼'}
                            {link.icon === 'youtube' && '📺'}
                            {link.icon === 'facebook' && '👥'}
                            {link.icon === 'mail' && '✉️'}
                            {link.icon === 'music' && '🎵'}
                            {link.icon === 'video' && '🎬'}
                            {link.icon === 'shopping' && '🛍️'}
                            {link.icon === 'coffee' && '☕'}
                            {link.icon === 'book' && '📖'}
                            {link.icon === 'code' && '💻'}
                            {link.icon === 'link' && '🔗'}
                          </span>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-white truncate">{link.title}</h3>
                          <p className="text-sm text-slate-400 truncate">{link.url}</p>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-slate-500">
                            {link.clicks || 0} clicks
                          </span>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => toggleLinkStatus(link)}
                            className="text-slate-400 hover:text-white"
                          >
                            {link.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(link)}
                            className="text-slate-400 hover:text-white"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(link.id)}
                            className="text-slate-400 hover:text-red-400"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </TabsContent>

              {/* Social Tab */}
              <TabsContent value="social">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h1 className="text-2xl font-bold text-white">Social Links</h1>
                    <p className="text-slate-400">Add your social media profiles</p>
                  </div>
                  <Button 
                    onClick={() => {
                      setEditingSocial(null);
                      setSocialFormData({ platform: 'twitter', url: '' });
                      setShowSocialDialog(true);
                    }}
                    className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Social
                  </Button>
                </div>

                {/* Social Links List */}
                <div className="space-y-3">
                  {socialLinks.length === 0 ? (
                    <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
                      <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4">
                        <Share2 className="w-8 h-8 text-slate-500" />
                      </div>
                      <h3 className="text-lg font-medium text-white mb-2">No social links yet</h3>
                      <p className="text-slate-400 mb-4">Add your social media profiles</p>
                      <Button 
                        onClick={() => setShowSocialDialog(true)}
                        className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Social Link
                      </Button>
                    </div>
                  ) : (
                    socialLinks.map((social) => {
                      const platform = SOCIAL_PLATFORMS.find(p => p.value === social.platform);
                      const Icon = platform ? socialIconMap[social.platform] : Globe;
                      
                      return (
                        <div 
                          key={social.id}
                          className="group flex items-center gap-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-violet-500/50 transition-all"
                        >
                          <div 
                            className="w-10 h-10 rounded-lg flex items-center justify-center"
                            style={{ backgroundColor: platform?.color + '20' }}
                          >
                            <Icon className="w-5 h-5" style={{ color: platform?.color }} />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-white">{platform?.label}</h3>
                            <p className="text-sm text-slate-400 truncate">{social.url}</p>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setEditingSocial(social);
                                setSocialFormData({ platform: social.platform, url: social.url });
                                setShowSocialDialog(true);
                              }}
                              className="text-slate-400 hover:text-white"
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteSocial(social.id)}
                              className="text-slate-400 hover:text-red-400"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Add/Edit Link Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>{editingLink ? 'Edit Link' : 'Add New Link'}</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                placeholder="e.g., My Website"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="url">URL</Label>
              <Input
                id="url"
                placeholder="https://example.com"
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Icon</Label>
                <Select 
                  value={formData.icon} 
                  onValueChange={(value) => setFormData({ ...formData, icon: value })}
                >
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {LINK_ICONS.map((icon) => (
                      <SelectItem key={icon.value} value={icon.value} className="text-white">
                        {icon.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Color</Label>
                <Select 
                  value={formData.color} 
                  onValueChange={(value) => setFormData({ ...formData, color: value })}
                >
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {LINK_COLORS.map((color) => (
                      <SelectItem key={color.value} value={color.value} className="text-white">
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded bg-gradient-to-r ${color.gradient}`} />
                          {color.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowAddDialog(false)}
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0"
              >
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : editingLink ? (
                  'Save Changes'
                ) : (
                  'Add Link'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Social Dialog */}
      <Dialog open={showSocialDialog} onOpenChange={setShowSocialDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>{editingSocial ? 'Edit Social Link' : 'Add Social Link'}</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSocialSubmit} className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Platform</Label>
              <Select 
                value={socialFormData.platform} 
                onValueChange={(value) => setSocialFormData({ ...socialFormData, platform: value as SocialPlatform })}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 max-h-60">
                  {SOCIAL_PLATFORMS.map((platform) => (
                    <SelectItem key={platform.value} value={platform.value} className="text-white">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-4 h-4 rounded" 
                          style={{ backgroundColor: platform.color }}
                        />
                        {platform.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="socialUrl">Profile URL</Label>
              <Input
                id="socialUrl"
                placeholder="https://..."
                value={socialFormData.url}
                onChange={(e) => setSocialFormData({ ...socialFormData, url: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
            
            <DialogFooter className="mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowSocialDialog(false)}
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white border-0"
              >
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : editingSocial ? (
                  'Save Changes'
                ) : (
                  'Add Social'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* QR Code Dialog */}
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-center">Your QR Code</DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center py-4">
            <div className="bg-white p-4 rounded-xl mb-4">
              {qrCodeUrl && (
                <img src={qrCodeUrl} alt="QR Code" className="w-48 h-48" />
              )}
            </div>
            
            <p className="text-slate-400 text-center mb-4">
              Share your profile with this QR code
            </p>
            
            <div className="flex gap-2 w-full">
              <Button
                variant="outline"
                className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800"
                onClick={() => setShowQRDialog(false)}
              >
                <X className="w-4 h-4 mr-2" />
                Close
              </Button>
              <Button
                className="flex-1 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white"
                onClick={downloadQR}
              >
                <QrCode className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
