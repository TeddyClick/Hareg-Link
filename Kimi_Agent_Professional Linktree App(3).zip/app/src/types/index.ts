export interface User {
  id: string;
  username: string;
  email: string;
  password?: string; // For internal use only
  displayName: string;
  bio: string;
  avatar: string | null;
  theme: ThemeType;
  isAdmin: boolean;
  isActive: boolean;
  isVerified: boolean;
  socialLinks: SocialLink[];
  createdAt: string;
  updatedAt: string;
}

export type ThemeType = 
  | 'dark' 
  | 'light' 
  | 'midnight' 
  | 'sunset' 
  | 'forest' 
  | 'ocean' 
  | 'ethiopian' 
  | 'minimal';

export interface SocialLink {
  id: string;
  platform: SocialPlatform;
  url: string;
  order: number;
}

export type SocialPlatform = 
  | 'twitter' 
  | 'instagram' 
  | 'facebook' 
  | 'linkedin' 
  | 'youtube' 
  | 'tiktok' 
  | 'github' 
  | 'telegram' 
  | 'whatsapp' 
  | 'snapchat'
  | 'pinterest'
  | 'spotify'
  | 'soundcloud'
  | 'twitch'
  | 'discord'
  | 'website';

export interface Link {
  id: string;
  userId: string;
  title: string;
  url: string;
  icon: string;
  color: string;
  isActive: boolean;
  order: number;
  clicks: number;
  createdAt: string;
  updatedAt: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  displayName?: string;
}

export interface ProfileUpdateData {
  displayName?: string;
  bio?: string;
  avatar?: string | null;
  theme?: ThemeType;
  socialLinks?: SocialLink[];
}

export interface LinkCreateData {
  title: string;
  url: string;
  icon?: string;
  color?: string;
}

export interface LinkUpdateData {
  title?: string;
  url?: string;
  icon?: string;
  color?: string;
  isActive?: boolean;
  order?: number;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalLinks: number;
  activeLinks: number;
  totalClicks: number;
  recentUsers: number;
  verifiedUsers: number;
}

export interface SearchResult {
  users: User[];
  total: number;
  page: number;
  totalPages: number;
}

export const THEMES: Record<ThemeType, { name: string; gradient: string; text: string; subtext: string; card: string; accent: string }> = {
  dark: {
    name: 'Dark',
    gradient: 'from-slate-950 via-slate-900 to-slate-950',
    text: 'text-white',
    subtext: 'text-slate-400',
    card: 'bg-slate-800/60 border-slate-700/50',
    accent: 'violet'
  },
  light: {
    name: 'Light',
    gradient: 'from-gray-50 to-gray-100',
    text: 'text-gray-900',
    subtext: 'text-gray-600',
    card: 'bg-white/80 border-gray-200',
    accent: 'violet'
  },
  midnight: {
    name: 'Midnight',
    gradient: 'from-indigo-950 via-purple-950 to-slate-950',
    text: 'text-white',
    subtext: 'text-indigo-200',
    card: 'bg-indigo-900/40 border-indigo-700/50',
    accent: 'indigo'
  },
  sunset: {
    name: 'Sunset',
    gradient: 'from-orange-900 via-red-900 to-purple-950',
    text: 'text-white',
    subtext: 'text-orange-200',
    card: 'bg-red-900/40 border-red-700/50',
    accent: 'orange'
  },
  forest: {
    name: 'Forest',
    gradient: 'from-emerald-950 via-green-900 to-teal-950',
    text: 'text-white',
    subtext: 'text-emerald-200',
    card: 'bg-emerald-900/40 border-emerald-700/50',
    accent: 'emerald'
  },
  ocean: {
    name: 'Ocean',
    gradient: 'from-blue-950 via-cyan-900 to-teal-950',
    text: 'text-white',
    subtext: 'text-cyan-200',
    card: 'bg-cyan-900/40 border-cyan-700/50',
    accent: 'cyan'
  },
  ethiopian: {
    name: 'Ethiopian',
    gradient: 'from-green-900 via-yellow-900 to-red-950',
    text: 'text-white',
    subtext: 'text-yellow-200',
    card: 'bg-green-900/40 border-yellow-600/50',
    accent: 'yellow'
  },
  minimal: {
    name: 'Minimal',
    gradient: 'from-white to-gray-50',
    text: 'text-gray-900',
    subtext: 'text-gray-500',
    card: 'bg-white border-gray-200',
    accent: 'gray'
  }
};

export const LINK_COLORS = [
  { value: 'blue', label: 'Blue', gradient: 'from-blue-500 to-blue-600' },
  { value: 'purple', label: 'Purple', gradient: 'from-violet-500 to-purple-600' },
  { value: 'pink', label: 'Pink', gradient: 'from-pink-500 to-rose-500' },
  { value: 'red', label: 'Red', gradient: 'from-red-500 to-red-600' },
  { value: 'orange', label: 'Orange', gradient: 'from-orange-500 to-amber-500' },
  { value: 'yellow', label: 'Yellow', gradient: 'from-yellow-400 to-amber-500' },
  { value: 'green', label: 'Green', gradient: 'from-emerald-500 to-teal-600' },
  { value: 'cyan', label: 'Cyan', gradient: 'from-cyan-500 to-blue-500' },
  { value: 'gray', label: 'Gray', gradient: 'from-gray-600 to-gray-700' },
  { value: 'ethiopia', label: 'Ethiopia', gradient: 'from-green-500 via-yellow-500 to-red-500' },
] as const;

export const LINK_ICONS = [
  { value: 'link', label: 'Link' },
  { value: 'globe', label: 'Website' },
  { value: 'github', label: 'GitHub' },
  { value: 'twitter', label: 'Twitter' },
  { value: 'instagram', label: 'Instagram' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'youtube', label: 'YouTube' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'mail', label: 'Email' },
  { value: 'music', label: 'Music' },
  { value: 'video', label: 'Video' },
  { value: 'shopping', label: 'Shop' },
  { value: 'coffee', label: 'Support' },
  { value: 'book', label: 'Blog' },
  { value: 'code', label: 'Code' },
] as const;

export const SOCIAL_PLATFORMS: { value: SocialPlatform; label: string; color: string; icon: string }[] = [
  { value: 'twitter', label: 'Twitter', color: '#1DA1F2', icon: 'twitter' },
  { value: 'instagram', label: 'Instagram', color: '#E4405F', icon: 'instagram' },
  { value: 'facebook', label: 'Facebook', color: '#1877F2', icon: 'facebook' },
  { value: 'linkedin', label: 'LinkedIn', color: '#0A66C2', icon: 'linkedin' },
  { value: 'youtube', label: 'YouTube', color: '#FF0000', icon: 'youtube' },
  { value: 'tiktok', label: 'TikTok', color: '#000000', icon: 'music' },
  { value: 'github', label: 'GitHub', color: '#333333', icon: 'github' },
  { value: 'telegram', label: 'Telegram', color: '#0088cc', icon: 'send' },
  { value: 'whatsapp', label: 'WhatsApp', color: '#25D366', icon: 'message-circle' },
  { value: 'snapchat', label: 'Snapchat', color: '#FFFC00', icon: 'ghost' },
  { value: 'pinterest', label: 'Pinterest', color: '#BD081C', icon: 'pin' },
  { value: 'spotify', label: 'Spotify', color: '#1DB954', icon: 'music' },
  { value: 'soundcloud', label: 'SoundCloud', color: '#FF5500', icon: 'cloud' },
  { value: 'twitch', label: 'Twitch', color: '#9146FF', icon: 'video' },
  { value: 'discord', label: 'Discord', color: '#5865F2', icon: 'message-square' },
  { value: 'website', label: 'Website', color: '#6366F1', icon: 'globe' },
];
