import type { 
  User, 
  Link, 
  LoginCredentials, 
  RegisterData, 
  ProfileUpdateData, 
  LinkCreateData, 
  LinkUpdateData,
  AdminStats,
  SocialLink,
  SearchResult,
  ThemeType
} from '@/types';

// Simulated delay for API calls
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Generate UUID
const generateId = () => Math.random().toString(36).substring(2) + Date.now().toString(36);

// Get JWT token
const getToken = () => localStorage.getItem('token');

// Initialize default data
const initializeData = () => {
  if (!localStorage.getItem('users')) {
    const defaultAdmin: User = {
      id: generateId(),
      username: 'admin',
      email: 'admin@hareglink.com',
      password: 'admin123',
      displayName: 'Hareg Admin',
      bio: 'Official Hareg Link Administrator 🇪🇹',
      avatar: null,
      theme: 'ethiopian',
      isAdmin: true,
      isActive: true,
      isVerified: true,
      socialLinks: [
        { id: generateId(), platform: 'twitter', url: 'https://twitter.com/hareglink', order: 0 },
        { id: generateId(), platform: 'telegram', url: 'https://t.me/hareglink', order: 1 },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Add some demo users
    const demoUsers: User[] = [
      defaultAdmin,
      {
        id: generateId(),
        username: 'abebe',
        email: 'abebe@example.com',
        password: 'password123',
        displayName: 'Abebe Kebede',
        bio: 'Ethiopian Artist & Creator 🎨🇪🇹',
        avatar: null,
        theme: 'ethiopian',
        isAdmin: false,
        isActive: true,
        isVerified: true,
        socialLinks: [
          { id: generateId(), platform: 'instagram', url: 'https://instagram.com/abebe', order: 0 },
          { id: generateId(), platform: 'youtube', url: 'https://youtube.com/abebe', order: 1 },
        ],
        createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
        updatedAt: new Date(Date.now() - 86400000 * 5).toISOString()
      },
      {
        id: generateId(),
        username: 'selam',
        email: 'selam@example.com',
        password: 'password123',
        displayName: 'Selam Tesfaye',
        bio: 'Fashion Blogger | Addis Ababa 📍',
        avatar: null,
        theme: 'sunset',
        isAdmin: false,
        isActive: true,
        isVerified: false,
        socialLinks: [
          { id: generateId(), platform: 'tiktok', url: 'https://tiktok.com/@selam', order: 0 },
          { id: generateId(), platform: 'instagram', url: 'https://instagram.com/selam', order: 1 },
        ],
        createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
        updatedAt: new Date(Date.now() - 86400000 * 3).toISOString()
      },
      {
        id: generateId(),
        username: 'dawit',
        email: 'dawit@example.com',
        password: 'password123',
        displayName: 'Dawit Mekonnen',
        bio: 'Software Developer | Tech Enthusiast 💻',
        avatar: null,
        theme: 'midnight',
        isAdmin: false,
        isActive: true,
        isVerified: false,
        socialLinks: [
          { id: generateId(), platform: 'github', url: 'https://github.com/dawit', order: 0 },
          { id: generateId(), platform: 'linkedin', url: 'https://linkedin.com/in/dawit', order: 1 },
          { id: generateId(), platform: 'twitter', url: 'https://twitter.com/dawit', order: 2 },
        ],
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        updatedAt: new Date(Date.now() - 86400000 * 2).toISOString()
      },
      {
        id: generateId(),
        username: 'mery',
        email: 'mery@example.com',
        password: 'password123',
        displayName: 'Mery Haile',
        bio: 'Food Blogger | Ethiopian Cuisine 🍽️🇪🇹',
        avatar: null,
        theme: 'forest',
        isAdmin: false,
        isActive: true,
        isVerified: true,
        socialLinks: [
          { id: generateId(), platform: 'youtube', url: 'https://youtube.com/mery', order: 0 },
          { id: generateId(), platform: 'instagram', url: 'https://instagram.com/mery', order: 1 },
          { id: generateId(), platform: 'facebook', url: 'https://facebook.com/mery', order: 2 },
        ],
        createdAt: new Date(Date.now() - 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 86400000).toISOString()
      },
    ];
    
    localStorage.setItem('users', JSON.stringify(demoUsers));
    localStorage.setItem('passwords', JSON.stringify({ 
      [defaultAdmin.id]: 'admin123',
      [demoUsers[1].id]: 'password123',
      [demoUsers[2].id]: 'password123',
      [demoUsers[3].id]: 'password123',
      [demoUsers[4].id]: 'password123',
    }));
    
    // Add demo links
    const demoLinks: Link[] = [
      { id: generateId(), userId: demoUsers[1].id, title: 'My Portfolio', url: 'https://abebe.art', icon: 'globe', color: 'ethiopia', isActive: true, order: 0, clicks: 156, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[1].id, title: 'Buy My Art', url: 'https://shop.abebe.art', icon: 'shopping', color: 'green', isActive: true, order: 1, clicks: 89, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[2].id, title: 'Latest Collection', url: 'https://selam.com/collection', icon: 'shopping', color: 'pink', isActive: true, order: 0, clicks: 234, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[2].id, title: 'Blog', url: 'https://selam.com/blog', icon: 'book', color: 'orange', isActive: true, order: 1, clicks: 123, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[3].id, title: 'GitHub', url: 'https://github.com/dawit', icon: 'github', color: 'gray', isActive: true, order: 0, clicks: 567, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[3].id, title: 'My Projects', url: 'https://dawit.dev', icon: 'code', color: 'blue', isActive: true, order: 1, clicks: 345, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[4].id, title: 'Recipes Book', url: 'https://mery.com/recipes', icon: 'book', color: 'red', isActive: true, order: 0, clicks: 890, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
      { id: generateId(), userId: demoUsers[4].id, title: 'YouTube Channel', url: 'https://youtube.com/mery', icon: 'video', color: 'red', isActive: true, order: 1, clicks: 1234, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    ];
    localStorage.setItem('links', JSON.stringify(demoLinks));
  }
  
  if (!localStorage.getItem('links')) {
    localStorage.setItem('links', JSON.stringify([]));
  }
};

initializeData();

// Database helpers
function readUsers(): User[] {
  return JSON.parse(localStorage.getItem('users') || '[]');
}

function writeUsers(users: User[]) {
  localStorage.setItem('users', JSON.stringify(users));
}

function readLinks(): Link[] {
  return JSON.parse(localStorage.getItem('links') || '[]');
}

function writeLinks(links: Link[]) {
  localStorage.setItem('links', JSON.stringify(links));
}

function readPasswords(): Record<string, string> {
  return JSON.parse(localStorage.getItem('passwords') || '{}');
}

function writePasswords(passwords: Record<string, string>) {
  localStorage.setItem('passwords', JSON.stringify(passwords));
}

// ==================== AUTH API ====================

export const authApi = {
  login: async (credentials: LoginCredentials): Promise<{ user: User; token: string }> => {
    await delay(500);
    
    const users = readUsers();
    const passwords = readPasswords();
    
    const user = users.find(u => 
      (u.username === credentials.username || u.email === credentials.username) && 
      passwords[u.id] === credentials.password
    );
    
    if (!user) {
      throw new Error('Invalid credentials');
    }
    
    if (!user.isActive) {
      throw new Error('Account is deactivated');
    }
    
    const token = btoa(JSON.stringify({ id: user.id, username: user.username, isAdmin: user.isAdmin }));
    localStorage.setItem('token', token);
    
    return { user, token };
  },

  register: async (data: RegisterData): Promise<{ user: User; token: string }> => {
    await delay(500);
    
    const users = readUsers();
    const passwords = readPasswords();
    
    if (users.find(u => u.username === data.username)) {
      throw new Error('Username already taken');
    }
    if (users.find(u => u.email === data.email)) {
      throw new Error('Email already registered');
    }
    
    const newUser: User = {
      id: generateId(),
      username: data.username,
      email: data.email,
      displayName: data.displayName || data.username,
      bio: '',
      avatar: null,
      theme: 'dark',
      isAdmin: false,
      isActive: true,
      isVerified: false,
      socialLinks: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    users.push(newUser);
    passwords[newUser.id] = data.password;
    
    writeUsers(users);
    writePasswords(passwords);
    
    const token = btoa(JSON.stringify({ id: newUser.id, username: newUser.username, isAdmin: newUser.isAdmin }));
    localStorage.setItem('token', token);
    
    return { user: newUser, token };
  },

  logout: () => {
    localStorage.removeItem('token');
  },

  getCurrentUser: async (): Promise<User | null> => {
    await delay(300);
    
    const token = getToken();
    if (!token) return null;
    
    try {
      const payload = JSON.parse(atob(token));
      const users = readUsers();
      return users.find(u => u.id === payload.id) || null;
    } catch {
      return null;
    }
  },

  updateProfile: async (data: ProfileUpdateData): Promise<User> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const users = readUsers();
    const userIndex = users.findIndex(u => u.id === payload.id);
    
    if (userIndex === -1) throw new Error('User not found');
    
    users[userIndex] = {
      ...users[userIndex],
      ...data,
      updatedAt: new Date().toISOString()
    };
    
    writeUsers(users);
    return users[userIndex];
  },

  changePassword: async (currentPassword: string, newPassword: string): Promise<void> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const passwords = readPasswords();
    
    if (passwords[payload.id] !== currentPassword) {
      throw new Error('Current password is incorrect');
    }
    
    passwords[payload.id] = newPassword;
    writePasswords(passwords);
  }
};

// ==================== LINKS API ====================

export const linksApi = {
  getMyLinks: async (): Promise<Link[]> => {
    await delay(300);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const links = readLinks();
    
    return links.filter(l => l.userId === payload.id).sort((a, b) => a.order - b.order);
  },

  createLink: async (data: LinkCreateData): Promise<Link> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const links = readLinks();
    const userLinks = links.filter(l => l.userId === payload.id);
    
    const newLink: Link = {
      id: generateId(),
      userId: payload.id,
      title: data.title,
      url: data.url,
      icon: data.icon || 'link',
      color: data.color || 'blue',
      isActive: true,
      order: userLinks.length,
      clicks: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    links.push(newLink);
    writeLinks(links);
    
    return newLink;
  },

  updateLink: async (id: string, data: LinkUpdateData): Promise<Link> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const links = readLinks();
    const linkIndex = links.findIndex(l => l.id === id && l.userId === payload.id);
    
    if (linkIndex === -1) throw new Error('Link not found');
    
    links[linkIndex] = {
      ...links[linkIndex],
      ...data,
      updatedAt: new Date().toISOString()
    };
    
    writeLinks(links);
    return links[linkIndex];
  },

  deleteLink: async (id: string): Promise<void> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const links = readLinks();
    const linkIndex = links.findIndex(l => l.id === id && l.userId === payload.id);
    
    if (linkIndex === -1) throw new Error('Link not found');
    
    links.splice(linkIndex, 1);
    writeLinks(links);
  },

  reorderLinks: async (linkIds: string[]): Promise<void> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    const links = readLinks();
    
    linkIds.forEach((id, index) => {
      const link = links.find(l => l.id === id && l.userId === payload.id);
      if (link) {
        link.order = index;
        link.updatedAt = new Date().toISOString();
      }
    });
    
    writeLinks(links);
  },

  trackClick: async (id: string): Promise<void> => {
    const links = readLinks();
    const link = links.find(l => l.id === id);
    
    if (link) {
      link.clicks = (link.clicks || 0) + 1;
      writeLinks(links);
    }
  }
};

// ==================== PUBLIC API ====================

export const publicApi = {
  getUserProfile: async (username: string): Promise<{ 
    username: string; 
    displayName: string; 
    bio: string; 
    avatar: string | null;
    theme: ThemeType;
    isVerified: boolean;
    socialLinks: SocialLink[];
    links: Link[];
  } | null> => {
    await delay(300);
    
    const users = readUsers();
    const user = users.find(u => u.username === username && u.isActive);
    
    if (!user) return null;
    
    const links = readLinks().filter(l => l.userId === user.id && l.isActive);
    
    return {
      username: user.username,
      displayName: user.displayName,
      bio: user.bio,
      avatar: user.avatar,
      theme: user.theme,
      isVerified: user.isVerified,
      socialLinks: user.socialLinks || [],
      links: links.sort((a, b) => a.order - b.order)
    };
  },

  searchUsers: async (query: string, page: number = 1, limit: number = 12): Promise<SearchResult> => {
    await delay(200);
    
    const users = readUsers();
    const links = readLinks();
    
    let filteredUsers = users.filter(u => u.isActive);
    
    if (query.trim()) {
      const lowerQuery = query.toLowerCase();
      filteredUsers = filteredUsers.filter(u => 
        u.username.toLowerCase().includes(lowerQuery) ||
        u.displayName.toLowerCase().includes(lowerQuery) ||
        u.bio.toLowerCase().includes(lowerQuery)
      );
    }
    
    // Sort by verified first, then by display name
    filteredUsers.sort((a, b) => {
      if (a.isVerified !== b.isVerified) return b.isVerified ? 1 : -1;
      return a.displayName.localeCompare(b.displayName);
    });
    
    const total = filteredUsers.length;
    const totalPages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    const paginatedUsers = filteredUsers.slice(start, start + limit);
    
    // Add link counts
    const usersWithCounts = paginatedUsers.map(u => ({
      ...u,
      linkCount: links.filter(l => l.userId === u.id && l.isActive).length
    }));
    
    return {
      users: usersWithCounts,
      total,
      page,
      totalPages
    };
  }
};

// ==================== ADMIN API ====================

export const adminApi = {
  getAllUsers: async (): Promise<User[]> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    return readUsers();
  },

  getUserById: async (id: string): Promise<User & { links: Link[] }> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    const users = readUsers();
    const user = users.find(u => u.id === id);
    
    if (!user) throw new Error('User not found');
    
    const links = readLinks().filter(l => l.userId === user.id);
    
    return { ...user, links };
  },

  updateUser: async (id: string, data: Partial<User>): Promise<User> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    if (payload.id === id && data.isActive === false) {
      throw new Error('Cannot deactivate your own account');
    }
    
    const users = readUsers();
    const userIndex = users.findIndex(u => u.id === id);
    
    if (userIndex === -1) throw new Error('User not found');
    
    users[userIndex] = {
      ...users[userIndex],
      ...data,
      updatedAt: new Date().toISOString()
    };
    
    writeUsers(users);
    return users[userIndex];
  },

  deleteUser: async (id: string): Promise<void> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    if (payload.id === id) {
      throw new Error('Cannot delete your own account');
    }
    
    // Delete user's links
    const links = readLinks();
    const filteredLinks = links.filter(l => l.userId !== id);
    writeLinks(filteredLinks);
    
    // Delete user
    const users = readUsers();
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex > -1) {
      users.splice(userIndex, 1);
      writeUsers(users);
    }
    
    // Delete password
    const passwords = readPasswords();
    delete passwords[id];
    writePasswords(passwords);
  },

  getAllLinks: async (): Promise<(Link & { username: string })[]> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    const links = readLinks();
    const users = readUsers();
    
    return links.map(link => {
      const user = users.find(u => u.id === link.userId);
      return { ...link, username: user?.username || 'Unknown' };
    });
  },

  getStats: async (): Promise<AdminStats> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    const users = readUsers();
    const links = readLinks();
    
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.isActive).length;
    const verifiedUsers = users.filter(u => u.isVerified).length;
    const totalLinks = links.length;
    const activeLinks = links.filter(l => l.isActive).length;
    const totalClicks = links.reduce((sum, link) => sum + (link.clicks || 0), 0);
    
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentUsers = users.filter(u => new Date(u.createdAt) > sevenDaysAgo).length;
    
    return {
      totalUsers,
      activeUsers,
      totalLinks,
      activeLinks,
      totalClicks,
      recentUsers,
      verifiedUsers
    };
  },

  // Admin can edit any user's full profile
  editUserFullProfile: async (
    id: string, 
    data: { 
      displayName?: string; 
      bio?: string; 
      username?: string;
      email?: string;
      theme?: ThemeType;
      isVerified?: boolean;
      isActive?: boolean;
      isAdmin?: boolean;
      socialLinks?: SocialLink[];
    }
  ): Promise<User> => {
    await delay(500);
    
    const token = getToken();
    if (!token) throw new Error('Not authenticated');
    
    const payload = JSON.parse(atob(token));
    if (!payload.isAdmin) throw new Error('Admin access required');
    
    const users = readUsers();
    const userIndex = users.findIndex(u => u.id === id);
    
    if (userIndex === -1) throw new Error('User not found');
    
    // Check username uniqueness if changing
    if (data.username && data.username !== users[userIndex].username) {
      if (users.find(u => u.username === data.username && u.id !== id)) {
        throw new Error('Username already taken');
      }
    }
    
    // Check email uniqueness if changing
    if (data.email && data.email !== users[userIndex].email) {
      if (users.find(u => u.email === data.email && u.id !== id)) {
        throw new Error('Email already registered');
      }
    }
    
    // Prevent self-demotion
    if (payload.id === id && data.isAdmin === false) {
      throw new Error('Cannot remove your own admin privileges');
    }
    
    users[userIndex] = {
      ...users[userIndex],
      ...data,
      updatedAt: new Date().toISOString()
    };
    
    writeUsers(users);
    return users[userIndex];
  }
};
