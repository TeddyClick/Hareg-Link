const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Middleware
app.use(cors());
app.use(express.json());

// Ensure data directory exists
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Database file paths
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const LINKS_FILE = path.join(DATA_DIR, 'links.json');

// Initialize database files if they don't exist
function initDatabase() {
  if (!fs.existsSync(USERS_FILE)) {
    // Create default admin user
    const defaultUsers = [
      {
        id: uuidv4(),
        username: 'admin',
        email: 'admin@linktree.com',
        password: 'admin123',
        displayName: 'Administrator',
        bio: 'System Administrator',
        avatar: null,
        theme: 'dark',
        isAdmin: true,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
    fs.writeFileSync(USERS_FILE, JSON.stringify(defaultUsers, null, 2));
  }
  
  if (!fs.existsSync(LINKS_FILE)) {
    fs.writeFileSync(LINKS_FILE, JSON.stringify([], null, 2));
  }
}

initDatabase();

// Database helpers
function readUsers() {
  return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
}

function writeUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

function readLinks() {
  return JSON.parse(fs.readFileSync(LINKS_FILE, 'utf8'));
}

function writeLinks(links) {
  fs.writeFileSync(LINKS_FILE, JSON.stringify(links, null, 2));
}

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

// Admin middleware
function requireAdmin(req, res, next) {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// ==================== AUTH ROUTES ====================

// Register
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, displayName } = req.body;
  
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Username, email, and password are required' });
  }
  
  const users = readUsers();
  
  if (users.find(u => u.username === username)) {
    return res.status(400).json({ error: 'Username already taken' });
  }
  if (users.find(u => u.email === email)) {
    return res.status(400).json({ error: 'Email already registered' });
  }
  
  const newUser = {
    id: uuidv4(),
    username,
    email,
    password,
    displayName: displayName || username,
    bio: '',
    avatar: null,
    theme: 'dark',
    isAdmin: false,
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  users.push(newUser);
  writeUsers(users);
  
  const token = jwt.sign(
    { id: newUser.id, username: newUser.username, isAdmin: newUser.isAdmin },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
  
  res.status(201).json({
    message: 'User registered successfully',
    token,
    user: {
      id: newUser.id,
      username: newUser.username,
      email: newUser.email,
      displayName: newUser.displayName,
      bio: newUser.bio,
      avatar: newUser.avatar,
      theme: newUser.theme,
      isAdmin: newUser.isAdmin
    }
  });
});

// Login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  
  const users = readUsers();
  const user = users.find(u => (u.username === username || u.email === username) && u.password === password);
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  
  if (!user.isActive) {
    return res.status(403).json({ error: 'Account is deactivated' });
  }
  
  const token = jwt.sign(
    { id: user.id, username: user.username, isAdmin: user.isAdmin },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
  
  res.json({
    message: 'Login successful',
    token,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      displayName: user.displayName,
      bio: user.bio,
      avatar: user.avatar,
      theme: user.theme,
      isAdmin: user.isAdmin
    }
  });
});

// Get current user
app.get('/api/auth/me', authenticateToken, (req, res) => {
  const users = readUsers();
  const user = users.find(u => u.id === req.user.id);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    displayName: user.displayName,
    bio: user.bio,
    avatar: user.avatar,
    theme: user.theme,
    isAdmin: user.isAdmin
  });
});

// ==================== USER PROFILE ROUTES ====================

// Update profile
app.put('/api/users/profile', authenticateToken, (req, res) => {
  const { displayName, bio, avatar, theme } = req.body;
  const users = readUsers();
  const userIndex = users.findIndex(u => u.id === req.user.id);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  users[userIndex] = {
    ...users[userIndex],
    displayName: displayName || users[userIndex].displayName,
    bio: bio !== undefined ? bio : users[userIndex].bio,
    avatar: avatar !== undefined ? avatar : users[userIndex].avatar,
    theme: theme || users[userIndex].theme,
    updatedAt: new Date().toISOString()
  };
  
  writeUsers(users);
  
  res.json({
    message: 'Profile updated successfully',
    user: {
      id: users[userIndex].id,
      username: users[userIndex].username,
      email: users[userIndex].email,
      displayName: users[userIndex].displayName,
      bio: users[userIndex].bio,
      avatar: users[userIndex].avatar,
      theme: users[userIndex].theme,
      isAdmin: users[userIndex].isAdmin
    }
  });
});

// Change password
app.put('/api/users/password', authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const users = readUsers();
  const userIndex = users.findIndex(u => u.id === req.user.id);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  if (users[userIndex].password !== currentPassword) {
    return res.status(400).json({ error: 'Current password is incorrect' });
  }
  
  users[userIndex].password = newPassword;
  users[userIndex].updatedAt = new Date().toISOString();
  writeUsers(users);
  
  res.json({ message: 'Password changed successfully' });
});

// Get public profile by username
app.get('/api/users/:username', (req, res) => {
  const users = readUsers();
  const user = users.find(u => u.username === req.params.username && u.isActive);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const links = readLinks().filter(l => l.userId === user.id && l.isActive);
  
  res.json({
    username: user.username,
    displayName: user.displayName,
    bio: user.bio,
    avatar: user.avatar,
    theme: user.theme,
    links: links.map(l => ({
      id: l.id,
      title: l.title,
      url: l.url,
      icon: l.icon,
      color: l.color,
      order: l.order
    })).sort((a, b) => a.order - b.order)
  });
});

// ==================== LINKS ROUTES ====================

// Get all links for current user
app.get('/api/links', authenticateToken, (req, res) => {
  const links = readLinks().filter(l => l.userId === req.user.id);
  res.json(links.sort((a, b) => a.order - b.order));
});

// Create new link
app.post('/api/links', authenticateToken, (req, res) => {
  const { title, url, icon, color } = req.body;
  
  if (!title || !url) {
    return res.status(400).json({ error: 'Title and URL are required' });
  }
  
  const links = readLinks();
  const userLinks = links.filter(l => l.userId === req.user.id);
  
  const newLink = {
    id: uuidv4(),
    userId: req.user.id,
    title,
    url,
    icon: icon || 'link',
    color: color || 'blue',
    isActive: true,
    order: userLinks.length,
    clicks: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  links.push(newLink);
  writeLinks(links);
  
  res.status(201).json(newLink);
});

// Update link
app.put('/api/links/:id', authenticateToken, (req, res) => {
  const { title, url, icon, color, isActive, order } = req.body;
  const links = readLinks();
  const linkIndex = links.findIndex(l => l.id === req.params.id && l.userId === req.user.id);
  
  if (linkIndex === -1) {
    return res.status(404).json({ error: 'Link not found' });
  }
  
  links[linkIndex] = {
    ...links[linkIndex],
    title: title !== undefined ? title : links[linkIndex].title,
    url: url !== undefined ? url : links[linkIndex].url,
    icon: icon !== undefined ? icon : links[linkIndex].icon,
    color: color !== undefined ? color : links[linkIndex].color,
    isActive: isActive !== undefined ? isActive : links[linkIndex].isActive,
    order: order !== undefined ? order : links[linkIndex].order,
    updatedAt: new Date().toISOString()
  };
  
  writeLinks(links);
  res.json(links[linkIndex]);
});

// Delete link
app.delete('/api/links/:id', authenticateToken, (req, res) => {
  const links = readLinks();
  const linkIndex = links.findIndex(l => l.id === req.params.id && l.userId === req.user.id);
  
  if (linkIndex === -1) {
    return res.status(404).json({ error: 'Link not found' });
  }
  
  links.splice(linkIndex, 1);
  writeLinks(links);
  
  res.json({ message: 'Link deleted successfully' });
});

// Reorder links
app.put('/api/links/reorder', authenticateToken, (req, res) => {
  const { linkIds } = req.body;
  const links = readLinks();
  
  linkIds.forEach((id, index) => {
    const link = links.find(l => l.id === id && l.userId === req.user.id);
    if (link) {
      link.order = index;
      link.updatedAt = new Date().toISOString();
    }
  });
  
  writeLinks(links);
  res.json({ message: 'Links reordered successfully' });
});

// Track link click
app.post('/api/links/:id/click', (req, res) => {
  const links = readLinks();
  const link = links.find(l => l.id === req.params.id);
  
  if (link) {
    link.clicks = (link.clicks || 0) + 1;
    writeLinks(links);
  }
  
  res.json({ success: true });
});

// ==================== ADMIN ROUTES ====================

// Get all users (admin only)
app.get('/api/admin/users', authenticateToken, requireAdmin, (req, res) => {
  const users = readUsers();
  res.json(users.map(u => ({
    id: u.id,
    username: u.username,
    email: u.email,
    displayName: u.displayName,
    isAdmin: u.isAdmin,
    isActive: u.isActive,
    createdAt: u.createdAt,
    updatedAt: u.updatedAt
  })));
});

// Get user details with links (admin only)
app.get('/api/admin/users/:id', authenticateToken, requireAdmin, (req, res) => {
  const users = readUsers();
  const user = users.find(u => u.id === req.params.id);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const links = readLinks().filter(l => l.userId === user.id);
  
  res.json({
    ...user,
    links
  });
});

// Update user (admin only)
app.put('/api/admin/users/:id', authenticateToken, requireAdmin, (req, res) => {
  const { displayName, bio, isAdmin, isActive } = req.body;
  const users = readUsers();
  const userIndex = users.findIndex(u => u.id === req.params.id);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  if (users[userIndex].id === req.user.id && isActive === false) {
    return res.status(400).json({ error: 'Cannot deactivate your own account' });
  }
  
  users[userIndex] = {
    ...users[userIndex],
    displayName: displayName !== undefined ? displayName : users[userIndex].displayName,
    bio: bio !== undefined ? bio : users[userIndex].bio,
    isAdmin: isAdmin !== undefined ? isAdmin : users[userIndex].isAdmin,
    isActive: isActive !== undefined ? isActive : users[userIndex].isActive,
    updatedAt: new Date().toISOString()
  };
  
  writeUsers(users);
  res.json(users[userIndex]);
});

// Delete user (admin only)
app.delete('/api/admin/users/:id', authenticateToken, requireAdmin, (req, res) => {
  const users = readUsers();
  const userIndex = users.findIndex(u => u.id === req.params.id);
  
  if (userIndex === -1) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  if (users[userIndex].id === req.user.id) {
    return res.status(400).json({ error: 'Cannot delete your own account' });
  }
  
  const links = readLinks();
  const filteredLinks = links.filter(l => l.userId !== req.params.id);
  writeLinks(filteredLinks);
  
  users.splice(userIndex, 1);
  writeUsers(users);
  
  res.json({ message: 'User deleted successfully' });
});

// Get all links (admin only)
app.get('/api/admin/links', authenticateToken, requireAdmin, (req, res) => {
  const links = readLinks();
  const users = readUsers();
  
  res.json(links.map(link => {
    const user = users.find(u => u.id === link.userId);
    return {
      ...link,
      username: user ? user.username : 'Unknown'
    };
  }));
});

// Get dashboard stats (admin only)
app.get('/api/admin/stats', authenticateToken, requireAdmin, (req, res) => {
  const users = readUsers();
  const links = readLinks();
  
  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.isActive).length;
  const totalLinks = links.length;
  const activeLinks = links.filter(l => l.isActive).length;
  const totalClicks = links.reduce((sum, link) => sum + (link.clicks || 0), 0);
  
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const recentUsers = users.filter(u => new Date(u.createdAt) > sevenDaysAgo).length;
  
  res.json({
    totalUsers,
    activeUsers,
    totalLinks,
    activeLinks,
    totalClicks,
    recentUsers
  });
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Admin credentials: admin / admin123`);
});
